from django.shortcuts import render, redirect
from .models import User
from django.conf import settings
from django.contrib import messages
from django.core.mail import send_mail
import random



def home(request):
    return render(request, 'home.html')

from django.shortcuts import render, redirect
from .models import User
from django.conf import settings
from django.contrib import messages
from django.core.mail import send_mail

from django.core.mail import send_mail
from django.conf import settings
from django.contrib import messages

def registration(request):
    if request.method == 'POST':
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        address = request.POST['address']
        password = request.POST['password']

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already exists. Please use another email.")
            return render(request, "reg.html", {"email_error": "Email already registered."})
        else:
            client = User(fname=fname, lname=lname, email=email, address=address, password=password)
            client.save()

            
            subject = "Welcome to Devil's Galaxee!"
            message = f"Hello {fname},\n\nWelcome to Devil's Galaxee!\n\nWe are thrilled to have you join our travel community. Get ready to explore amazing travel destinations with us.\n\nBest Regards,\nDevil's Galaxee Team"
            from_email = settings.EMAIL_HOST_USER
            recipient_list = [email]

            try:
                send_mail(subject, message, from_email, recipient_list, fail_silently=False)
                messages.success(request, "Registration successful! A welcome email has been sent.")
            except Exception as e:
                messages.error(request, f"Registration successful, but email could not be sent. Error: {str(e)}")

            return redirect('login')

    return render(request, 'reg.html')





import random
from django.shortcuts import render, redirect
from django.core.mail import send_mail
from django.contrib import messages
from django.conf import settings
from .models import User

def login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password=request.POST['password']
        user=User.objects.get(email=email)

       
        if not User.objects.filter(email=email).exists():
            messages.error(request, 'Email does not Exist')
            return render(request, "login.html", {"email_error": "Email Not registered please Register."})

        if user.password!=password:
            messages.error(request, 'Password incorrect Enter Correct password')
            return render(request, "login.html", {"password_error": "Password Incorrect Enter Correct Password"})
            


        otp = random.randint(1000, 9999)
        request.session['otp'] = otp  
        request.session['email'] = email  

       
        subject = "Your OTP Code for Login"
        message = f"Your OTP code is {otp}. Please enter it to log in."
        from_email = settings.EMAIL_HOST_USER
        recipient_list = [email]

        try:
            send_mail(subject, message, from_email, recipient_list, fail_silently=False)
            return render(request, 'otp_verification.html', {"email": email})  
        except Exception as e:
            messages.error(request, "OTP sending failed. Try again.")
            return redirect('login')

    return render(request, 'login.html')

def verify_otp(request):
    if request.method == 'POST':
        entered_otp = request.POST['otp']
        session_otp = request.session.get('otp')
        
        if session_otp and str(session_otp) == entered_otp:
            return redirect('dash')
        else:
            return render(request, 'otp_verification.html', {"otp_error": "Invalid OTP. Try again."})
    
    return redirect('login')


def dashboard(request):
    return render(request,'dashboard.html')

import requests
from django.shortcuts import render, redirect
from geopy.geocoders import Nominatim
from geopy.distance import geodesic
from datetime import datetime, timedelta
import concurrent.futures

geolocator = Nominatim(user_agent="MyTravelApp/1.0", timeout=15)

AVERAGE_SPEED_KMH = 60  

def get_coordinates(location):
    try:
        location_data = geolocator.geocode(location)
        if location_data:
            return location_data.latitude, location_data.longitude
    except Exception as e:
        print(f"Error fetching coordinates for {location}: {e}")
    return None

def get_place_name(lat, lon):
    try:
        location_data = geolocator.reverse((lat, lon), language="en")
        if location_data and "address" in location_data.raw:
            address = location_data.raw["address"]
            return f"{address.get('road', 'Unknown Place')}, {address.get('city', address.get('town', 'Unknown City'))}"
    except Exception as e:
        print(f"Error fetching place name for ({lat}, {lon}): {e}")
    return "Unknown Place, Unknown City"


def estimate_travel_cost(distance_km):
    cost_per_km = 5 
    return distance_km * cost_per_km


def get_nearby_places(lat, lon, category):
    overpass_url = "https://overpass-api.de/api/interpreter"
    radius = 10000  

    queries = {
        "Devotional Places": f'node(around:{radius},{lat},{lon})["amenity"~"place_of_worship|temple|church|mosque|synagogue"];out;',
        "Historical Places": f'node(around:{radius},{lat},{lon})["historic"];out;',
        "Famous Places": f'node(around:{radius},{lat},{lon})["tourism"~"attraction|museum|viewpoint|zoo"];out;',
        "Good Nature Places": f'node(around:{radius},{lat},{lon})["leisure"~"park|nature_reserve|garden|beach|forest"];out;'
    }

    query = queries.get(category, "")
    if not query:
        return []

    try:
        response = requests.get(overpass_url, params={"data": f'[out:json];{query}'}, timeout=15)
        response.raise_for_status()
        data = response.json()

        places = [
            f"{element['tags'].get('name', 'Unknown Place')} ({get_place_name(element['lat'], element['lon'])})"
            for element in data.get("elements", []) if "lat" in element and "lon" in element
        ]
        return places[:5] 
    except requests.exceptions.RequestException as e:
        print(f"Error fetching {category}: {e}")
        return []


def calculate_stops(from_coords, to_coords, days):
    total_distance = geodesic(from_coords, to_coords).kilometers
    daily_distance = total_distance / days

    stops = []
    start_time = datetime.strptime("08:00", "%H:%M")  

    for day in range(1, days + 1):
        lat = from_coords[0] + (to_coords[0] - from_coords[0]) * (day / days)
        lon = from_coords[1] + (to_coords[1] - from_coords[1]) * (day / days)

        travel_time_hours = daily_distance / AVERAGE_SPEED_KMH
        arrival_time = start_time + timedelta(hours=travel_time_hours)

        stops.append({
            "lat": lat,
            "lon": lon,
            "time": arrival_time.strftime("%I:%M %p")  
        })
        start_time = arrival_time + timedelta(hours=2)  

    return stops


def addtrip(request):
    if request.method == "POST":
        from_location = request.POST.get("sl")
        to_location = request.POST.get("dest")
        budget = float(request.POST.get("budget"))
        start_date = request.POST.get("sd")
        end_date = request.POST.get("ed")

        try:
            start_date = datetime.strptime(start_date, "%Y-%m-%d")
            end_date = datetime.strptime(end_date, "%Y-%m-%d")
        except ValueError:
            return render(request, "addtrip.html", {"error": "Invalid date format."})

        days = (end_date - start_date).days + 1
        if days <= 0:
            return render(request, "addtrip.html", {"error": "End date must be after start date."})

        from_coords = get_coordinates(from_location)
        to_coords = get_coordinates(to_location)

        if not from_coords or not to_coords:
            return render(request, "addtrip.html", {"error": "Could not find coordinates for locations."})

        total_distance = geodesic(from_coords, to_coords).kilometers
        estimated_cost = estimate_travel_cost(total_distance)

        if budget < estimated_cost:
            return render(request, "addtrip.html", {"error": f"Budget too low! Estimated cost: ₹{estimated_cost}"})

        stops = calculate_stops(from_coords, to_coords, days)
        daily_budget = budget / days

        categories = ["Devotional Places", "Historical Places", "Famous Places", "Good Nature Places"]
        trip_plan = []

        for day, stop in enumerate(stops, start=1):
            lat, lon = stop["lat"], stop["lon"]
            trip_day = start_date + timedelta(days=day - 1)
            place_name = get_place_name(lat, lon)

            places_info = {}
            with concurrent.futures.ThreadPoolExecutor() as executor:
                results = {executor.submit(get_nearby_places, lat, lon, category): category for category in categories}
                for future in concurrent.futures.as_completed(results):
                    category = results[future]
                    places_info[category] = future.result()

            trip_plan.append({
                "day": day,
                "date": trip_day.strftime('%Y-%m-%d'),
                "location": place_name,
                "arrival_time": stop["time"],
                "places": places_info
            })

        return render(request, "plan.html", {
            "from_location": from_location,
            "to_location": to_location,
            "budget": budget,
            "estimated_cost": estimated_cost,
            "start_date": start_date.strftime('%Y-%m-%d'),
            "end_date": end_date.strftime('%Y-%m-%d'),
            "trip_plan": trip_plan
        })

    return render(request, "addtrip.html")

def plan(request):
    return render(request, "plan.html")
