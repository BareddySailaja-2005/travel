from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path("",views.home,name="login"),
    path("registration",views.registration,name="registration"),
    path("login",views.login,name="login"),
     path('verify_otp/', views.verify_otp, name='verify_otp'),
    path("dash",views.dashboard,name="dash"),
        path("add",views.addtrip,name="add"),
        path("plan",views.plan,name="plan"),






]